import { createBrowserRouter } from "react-router";

import RootLayout from "@/layouts/RootLayout";
import AuthLayout from "@/layouts/AuthLayout";
import PortalLayout from "@/layouts/PortalLayout";
import AgentLayout from "@/layouts/AgentLayout";
import ProtectedRoute from "@/components/ProtectedRoute";

import HomePage from "@/pages/HomePage";
import ServicesPage from "@/pages/ServicesPage";
import PricingPage from "@/pages/PricingPage";
import CaseStudiesPage from "@/pages/CaseStudiesPage";
import AboutPage from "@/pages/AboutPage";
import ContactPage from "@/pages/ContactPage";
import BookCallPage from "@/pages/BookCallPage";
import PalacioRunPage from "@/pages/PalacioRunPage";
import PressPage from "@/pages/PressPage";

import LoginPage from "@/pages/LoginPage";
import SignupPage from "@/pages/SignupPage";
import ForgotPasswordPage from "@/pages/ForgotPasswordPage";

import PortalDashboardPage from "@/pages/PortalDashboardPage";
import PortalMarketingOSPage from "@/pages/PortalMarketingOSPage";
import PortalExecutionEnginePage from "@/pages/PortalExecutionEnginePage";
import PortalCampaignsPage from "@/pages/PortalCampaignsPage";
import PortalAnalyticsPage from "@/pages/PortalAnalyticsPage";
import PortalDeliverablesPage from "@/pages/PortalDeliverablesPage";
import PortalInvoicesPage from "@/pages/PortalInvoicesPage";
import PortalNotificationsPage from "@/pages/PortalNotificationsPage";
import PortalSettingsPage from "@/pages/PortalSettingsPage";

import AgentClientsPage from "@/pages/AgentClientsPage";
import AgentCampaignsPage from "@/pages/AgentCampaignsPage";
import AgentUsersPage from "@/pages/AgentUsersPage";
import AgentTasksPage from "@/pages/AgentTasksPage";
import AgentAnalyticsPage from "@/pages/AgentAnalyticsPage";
import AgentNotesPage from "@/pages/AgentNotesPage";
import AgentSopLibraryPage from "@/pages/AgentSopLibraryPage";
import AgentKnowledgeBasePage from "@/pages/AgentKnowledgeBasePage";
import AgentAIExecutivePage from "@/pages/AgentAIExecutivePage";

import NotFoundPage from "@/pages/NotFoundPage";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "services", element: <ServicesPage /> },
      { path: "pricing", element: <PricingPage /> },
      { path: "case-studies", element: <CaseStudiesPage /> },
      { path: "about", element: <AboutPage /> },
      { path: "contact", element: <ContactPage /> },
      { path: "book-a-call", element: <BookCallPage /> },
      { path: "palacio-run", element: <PalacioRunPage /> },
      { path: "press", element: <PressPage /> },
    ],
  },
  {
    element: <AuthLayout />,
    children: [
      { path: "login", element: <LoginPage /> },
      { path: "signup", element: <SignupPage /> },
      { path: "forgot-password", element: <ForgotPasswordPage /> },
    ],
  },
  {
    path: "/portal",
    element: (
      <ProtectedRoute allowedRoles={["client", "admin"]}>
        <PortalLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <PortalDashboardPage /> },
      { path: "marketing-os", element: <PortalMarketingOSPage /> },
      { path: "execution-engine", element: <PortalExecutionEnginePage /> },
      { path: "campaigns", element: <PortalCampaignsPage /> },
      { path: "analytics", element: <PortalAnalyticsPage /> },
      { path: "deliverables", element: <PortalDeliverablesPage /> },
      { path: "invoices", element: <PortalInvoicesPage /> },
      { path: "notifications", element: <PortalNotificationsPage /> },
      { path: "settings", element: <PortalSettingsPage /> },
    ],
  },
  {
    path: "/agent",
    element: (
      <ProtectedRoute allowedRoles={["admin"]}>
        <AgentLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <AgentClientsPage /> },
      { path: "campaigns", element: <AgentCampaignsPage /> },
      { path: "users", element: <AgentUsersPage /> },
      { path: "tasks", element: <AgentTasksPage /> },
      { path: "analytics", element: <AgentAnalyticsPage /> },
      { path: "notes", element: <AgentNotesPage /> },
      { path: "sop-library", element: <AgentSopLibraryPage /> },
      { path: "knowledge-base", element: <AgentKnowledgeBasePage /> },
      { path: "ai-executive", element: <AgentAIExecutivePage /> },
    ],
  },
  { path: "*", element: <NotFoundPage /> },
]);
