# Supabase

Empty on purpose in Phase 1. Phase 3 (Supabase backend) adds:

- `migrations/` — SQL migrations for `users`, `organizations`, `campaigns`, `projects`,
  `tasks`, `deliverables`, `analytics`, `billing`, `notifications`,
  `intake_submissions`, `agent_activity`, `sop_library`, `ai_requests`
- Row Level Security (RLS) policies per table
- Indexes
- Seed data for local development

To use this folder once Phase 3 lands, install the [Supabase CLI](https://supabase.com/docs/guides/cli),
run `supabase init` if you haven't linked a project yet, then `supabase db push`
to apply migrations to your project.
